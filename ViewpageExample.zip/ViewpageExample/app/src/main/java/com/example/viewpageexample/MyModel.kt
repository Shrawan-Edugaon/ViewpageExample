package com.example.viewpageexample

import android.icu.text.CaseMap

class MyModel(
    var title: String,
    var description: String,
    var data: String,
    var image: Int
)